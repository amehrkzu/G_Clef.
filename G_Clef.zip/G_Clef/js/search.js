(function() {
    // セキュリティ強化のため、通信プロトコルを明示的に指定
    const _0xid = '1vzJ5TIUj-9xJuRN3CAprPBQIZPL5rQcKGpCXBWDkK8g';
    const _0xcfg = [
        { gid: '0', name: 'ID:ドロップ' },
        { gid: '280076559', name: 'ID:制作' },
        { gid: '2088543273', name: '討伐討滅:ドロップ' },
        { gid: '927050495', name: '討伐討滅:制作' },
        { gid: '1476306407', name: 'アライアンス:ドロップ' },
        { gid: '1004826655', name: 'アライアンス:制作' },
        { gid: '481213368', name: 'レイド' },
        { gid: '1084391822', name: 'その他:ドロップ' },
        { gid: '2142137428', name: 'その他:制作' },
        { gid: '377897272', name: 'その他:交換' },
        { gid: '883228920', name: '店売り譜面' }
    ];

    let _0xdata = [];
    let _0xcart = new Set();
    let _0xcartItems = new Map();
    let _0xfilter = new Set();

    function _0xapplyFilter() {
        const inp = document.getElementById('searchInput');
        const val = inp ? inp.value.toLowerCase().trim() : '';
        let result = _0xdata;
        if (_0xfilter.size > 0) {
            result = result.filter(item => _0xfilter.has(item.sName));
        }
        if (val) {
            result = result.filter(item =>
                item.cells.some(c => c && c.toLowerCase().includes(val)) ||
                item.sName.toLowerCase().includes(val)
            );
        }
        _0xrender(result);
    }

    function _0xbuildFilterBtns() {
        const area = document.getElementById('filterArea');
        if (!area) return;
        _0xcfg.forEach(c => {
            const btn = document.createElement('button');
            btn.className = 'filter-btn';
            btn.textContent = c.name;
            btn.addEventListener('click', () => {
                if (_0xfilter.has(c.name)) {
                    _0xfilter.delete(c.name);
                    btn.classList.remove('active');
                } else {
                    _0xfilter.add(c.name);
                    btn.classList.add('active');
                }
                _0xapplyFilter();
            });
            area.appendChild(btn);
        });
    }

    function _0xsparkle(el) {
        const rect    = el.getBoundingClientRect();
        const symbols = ['✦', '★', '✧', '♪', '♫', '◆', '✶', '❋'];
        const colors  = ['#c9a84c', '#e8d5a3', '#ffffff', '#f5d76e', '#ffeaa0'];
        const count   = 16;

        for (let i = 0; i < count; i++) {
            const p = document.createElement('span');
            p.className = 'sparkle-particle';
            p.textContent = symbols[i % symbols.length];

            const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.8;
            const dist  = 55 + Math.random() * 90;

            p.style.cssText = [
                `left:${rect.left + Math.random() * rect.width}px`,
                `top:${rect.top + rect.height / 2}px`,
                `color:${colors[Math.floor(Math.random() * colors.length)]}`,
                `font-size:${7 + Math.random() * 13}px`,
                `--dx:${(Math.cos(angle) * dist).toFixed(1)}px`,
                `--dy:${(Math.sin(angle) * dist - 50).toFixed(1)}px`,
                `--dur:${(0.5 + Math.random() * 0.45).toFixed(2)}s`,
                `--delay:${(Math.random() * 0.1).toFixed(2)}s`,
            ].join(';');

            document.body.appendChild(p);
            p.addEventListener('animationend', () => p.remove(), { once: true });
        }
    }

    function _0xcartKey(item) {
        return item.sName + '||' + (item.cells[0] || '') + '||' + (item.cells[1] || '');
    }

    function _0xcartDispatch() {
        window.dispatchEvent(new CustomEvent('cartUpdate', {
            detail: { count: _0xcart.size, items: Array.from(_0xcartItems.values()) }
        }));
    }

    window._0xcartClear = function() {
        _0xcart.clear();
        _0xcartItems.clear();
        document.querySelectorAll('#tableBody input[type="checkbox"]').forEach(cb => cb.checked = false);
        _0xcartDispatch();
    };

    window._0xcartRemove = function(key) {
        _0xcart.delete(key);
        _0xcartItems.delete(key);
        const cb = document.querySelector(`#tableBody input[data-key="${CSS.escape(key)}"]`);
        if (cb) cb.checked = false;
        _0xcartDispatch();
    };

    function _0xload(c) {
        return new Promise((resolve) => {
            const cbName = `jsonp_cb_${c.gid}_${Math.floor(Math.random() * 100000)}`;
            window[cbName] = function(d) {
                const r = [];
                try {
                    const rows = d.table.rows;
                    for (let i = 0; i < rows.length; i++) {
                        const row = rows[i];
                        if (!row || !row.c) continue;
                        const b = row.c[1] ? String(row.c[1].v || '') : '';
                        if (b.trim() !== "") {
                            r.push({
                                sName: c.name,
                                cells: [
                                    b,
                                    row.c[2] ? String(row.c[2].v || '') : '',
                                    row.c[3] ? String(row.c[3].v || '') : '',
                                    row.c[4] ? String(row.c[4].v || '') : ''
                                ]
                            });
                        }
                    }
                } catch (e) {
                    // エラーを隠蔽
                }
                document.body.removeChild(scr);
                delete window[cbName];
                resolve(r);
            };
            const scr = document.createElement('script');
            // ★URLの先頭を「https://」に完全固定し、GitHub上での暗号化通信エラーを確実に回避します
            scr.src = `https://docs.google.com/spreadsheets/d/${_0xid}/gviz/tq?tqx=responseHandler:${cbName}&gid=${c.gid}`;
            document.body.appendChild(scr);
        });
    }

    async function _0xinit() {
        const p = _0xcfg.map(c => _0xload(c));
        const res = await Promise.all(p);
        _0xdata = res.flat();
        
        const lv = document.getElementById('loadingView');
        const rt = document.getElementById('resultTable');
        if (lv) lv.style.display = 'none';
        if (rt) rt.style.display = 'table';
        
        const inp = document.getElementById('searchInput');
        if (inp) {
            inp.removeAttribute('disabled');
            inp.focus();
        }
        
        const status = document.getElementById('loadStatus');
        if (status) status.style.display = 'none';
        
        _0xbuildFilterBtns();
        _0xapplyFilter();

        if (inp) {
            inp.addEventListener('input', _0xapplyFilter);
        }
    }

    function _0xrender(d) {
        const body = document.getElementById('tableBody');
        if (!body) return;
        body.innerHTML = '';
        if (d.length === 0) {
            body.innerHTML = '<tr><td colspan="6" class="no-result">キーワードに一致する譜面がありません</td></tr>';
            return;
        }
        d.forEach(item => {
            const key = _0xcartKey(item);
            const tr = document.createElement('tr');

            const tdCb = document.createElement('td');
            tdCb.style.cssText = 'text-align:center; width:40px;';
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.style.cssText = 'width:16px; height:16px; cursor:pointer; accent-color:#3498db;';
            cb.dataset.key = key;
            cb.checked = _0xcart.has(key);
            const stock = (item.cells[2] || '').trim();
            const outOfStock = stock === '' || stock === '0';
            if (outOfStock) {
                cb.disabled = true;
                cb.style.cursor = 'not-allowed';
                tr.classList.add('out-of-stock');
            }
            cb.addEventListener('change', () => {
                if (cb.checked) {
                    tr.classList.remove('row-pop');
                    void tr.offsetWidth;
                    tr.classList.add('row-pop');
                    setTimeout(() => tr.classList.remove('row-pop'), 420);
                    _0xsparkle(tr);
                }

                if (cb.checked) {
                    _0xcart.add(key);
                    _0xcartItems.set(key, Object.assign({ _key: key }, item));
                } else {
                    _0xcart.delete(key);
                    _0xcartItems.delete(key);
                }
                _0xcartDispatch();
            });
            tdCb.appendChild(cb);
            tr.appendChild(tdCb);

            tr.addEventListener('click', (e) => {
                if (e.target === cb) return;
                if (cb.disabled) return;
                cb.checked = !cb.checked;
                cb.dispatchEvent(new Event('change'));
            });

            const tdS = document.createElement('td');
            const span = document.createElement('span');
            span.className = 'badge-sheet';
            span.textContent = item.sName;
            tdS.appendChild(span);
            tr.appendChild(tdS);

            for (let i = 0; i < 4; i++) {
                const td = document.createElement('td');
                td.textContent = item.cells[i] || '';
                tr.appendChild(td);
            }
            body.appendChild(tr);
        });
    }

    window.addEventListener('DOMContentLoaded', _0xinit);
})();